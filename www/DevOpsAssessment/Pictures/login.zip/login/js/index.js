$('.switch').click(function(){
   $(this).children('i').toggleClass('fa-pencil');
   $('.login').animate({height: "toggle", opacity: "toggle"}, "slow");
   $('.register').animate({height: "toggle", opacity: "toggle"}, "slow");
});

$('#nextBtn').click(function() {
	localStorage.setItem('serviceType', $('#serviceType').val());
	localStorage.setItem('appName', $('#appName').val());
	localStorage.setItem('yourName', $('#yourName').val());
	localStorage.setItem('designation', $('#designation').val());
	window.location.href = 'flowselection.html';
});

$('#tools').click(function() {
	window.location.href = 'assessment.html#second';
    if (typeof(Storage) !== "undefined") {
	    localStorage.assessment = "second";
	    document.getElementById("notes").innerHTML = "Last name: " + localStorage.assessment;
	} else {
	    document.getElementById("notes").innerHTML = "Sorry, your browser does not support web storage...";
	}


});
	
$('#process').click(function() {
	window.location.href = 'assessment.html';
	if (typeof(Storage) !== "undefined") {
	    localStorage.assessment = "first";
	    document.getElementById("notes").innerHTML = "Last name: " + localStorage.assessment;
	} else {
	    document.getElementById("notes").innerHTML = "Sorry, your browser does not support web storage...";
	}
	// return true or false, depending on whether you want to allow the `href` property to follow through or not

});